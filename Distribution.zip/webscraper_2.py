from bs4 import BeautifulSoup
from twilio.rest import Client
import urllib.request
# from htmlpage import url
from distutils.util import strtobool
from var import debug
import time
readLink=''
timeToScan = input('time in mins between scan')
def main():
 
 global debug
 account_sid = "AC4608a11d47e81b63bacf49e971b37a6d"
 auth_token = "1c7acc0edb9999293d401b3826d83a57"
 client = Client(account_sid, auth_token)
 messageBody = ""
 sendMessage=False 
 global readLink
 urlToScrape = 'https://www.amazon.com/Best-Sellers/zgbs' #amazon top page
 f = open('htmlpage.py', mode='a+')
 fp = urllib.request.urlopen(str(urlToScrape))
 mybytes = fp.read()
 i = False
 mystr = mybytes.decode("utf8")
 fp.close()
 html_doc=mystr
 soup = BeautifulSoup(html_doc, 'html.parser') #bsoup code. 
 link = soup.find('a', attrs={'class' : 'a-link-normal'})
 endlink = link['href']
 fulllink = 'amazon.com'+endlink
 if fulllink != readLink.lstrip(): #decides what to text
   messageBody = 'The number one toy has changed! '
 else:
   messageBody = "The number one toy is the same! "
 f.write("url = '" + fulllink + "'\n") 
 fp = urllib.request.urlopen('https://'+str(fulllink))
 mybytes = fp.read()
 i = False
 mystr = mybytes.decode("utf8")
 fp.close()
 html_doc=mystr
 soup2 = BeautifulSoup(html_doc, 'html.parser')
 title = soup2.find('span', attrs={'id' : 'productTitle'}).text #finds the title of the highest toy
 title = str(title)
 
 message = client.messages \
                 .create(
                      body="This is the Web-Scraper. " + messageBody + 'The current leader is: '+ title.lstrip().rstrip() +" This can be found here: " + fulllink, 
                      from_='+18607242381',
                      to='+19713419489'
                  )
 print(message.sid)
 if debug: #debug: prints variables. Not important
  print('sendMessage ' + str(sendMessage))
  print('messageBody '+ messageBody)
  print('fulllink '+fulllink)
  print('readlink ' + readLink)
  print('title ' + title.lstrip().rstrip())
 print(messageBody)
 readLink = fulllink
 time.sleep(int(timeToScan)*60)
 main()
main()

