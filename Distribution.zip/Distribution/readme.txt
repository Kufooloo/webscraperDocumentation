Requires Bs4 and twilio libs
Debug: Prints all vars
sendMessage: Sends a text messsage