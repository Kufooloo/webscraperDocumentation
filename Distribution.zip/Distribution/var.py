debug = False
sendMessage=True